# Tidrapport Pro

En Android-anpassad PWA för tidrapportering.

## Funktioner
- Datum, projekt, kund, arbetsplats, timmar, kilometer och kommentar
- Flera projekt samma dag
- Redigera och ta bort rapporter
- Sök i historik
- Statistik
- Export till CSV, Excel och PDF/utskrift
- Mörkt läge
- Offline-stöd
- Installerbar på Android via Chrome

## Ladda upp till GitHub
1. Packa upp ZIP-filen.
2. Gå till ditt GitHub repository.
3. Klicka på Add file → Upload files.
4. Dra in alla filer från mappen.
5. Klicka på Commit changes.

## GitHub Pages
Gå till Settings → Pages → välj branch main och folder root.
